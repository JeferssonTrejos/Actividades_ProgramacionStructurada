//Comprobacion del dato ingresado
function isNumber(num){
    if(isNaN(num) || num.trim() == ""){
        return isNumber(prompt('El dato ingresado no es un numero,  vuelve a ingresarlo: '))
    }else{
        
        return num
    }
}

//Encontrando numeros divisibles 
function evenlyDivisible(start,end,divisor){
    let dividers = []
    for(i=start; i<=end; i++){
        if(i%divisor == 0){
            dividers.push(i)
        }
    }
    return dividers
}



//Parametros
const numbers = [
    isNumber(prompt('Ingrese el inicio del rango:')),
    isNumber(prompt('Ingrese el final del rando:')),
    isNumber(prompt('Ingrese el divisor:'))
];

//Resultados
const numDivisible = evenlyDivisible(numbers[0],numbers[1],numbers[2])
    
if(numDivisible.length == 0){
    console.log('---- Arreglo vacio ----')
    console.log(`Numeros entre ${numbers[0]} y ${numbers[1]} no son divibles entre ${numbers[2]}`)
}else{
    console.log("---- Resultados ----")
    console.log(numDivisible)
}
